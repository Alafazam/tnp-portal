<script>
  $.validate();
</script>
    </div>
</body>
</html>