<?php 
$data = array('jobs' =>$jobs ,'student_jobs'=>$student_jobs,'users'=>$users);

var_dump($data);



 ?>