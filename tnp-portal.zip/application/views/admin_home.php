<link rel="stylesheet" href="/css/timeline.css">

<div class="container-fluid">
		<h2>Announcements</h2>
		<legend></legend>

		<h1>Hello Admin</h1>
    
	</div>
</div>
