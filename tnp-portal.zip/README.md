For Ankit sir to do.. :)

1. calender implement karna hai jo student ko dikhe with all company names
but company ko jahan date pic karni ho usko busy day aur open day type me hi dikhe (baki companies k naam na dikhe)
2. reset password/forgot  password banana hai
3. ADMIN k liye panel banana hai jaha wo:
      1. companies ko login password bna k de sake
      2. announcements daal sake
      3. company jo job vacancy create karegi uss ko ko finalise/approve kar sake taki to students k announcements section me ajaye
4.student profile me ja ke ctrl+P karne pe form ki details sari print hoti toh hai but formatting theek nahi hoti.. uske  print wali CSS dekh lena.. taki wo resume jasia lagne lage.. :)